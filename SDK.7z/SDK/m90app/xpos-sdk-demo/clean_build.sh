LINUX_PLAT_COMPONENT_LINUX=`pwd`/../..
export LINUX_PLAT_COMPONENT_LINUX

cd ./build 
make clean && make

