#pragma once
void sdk_simple_page();
