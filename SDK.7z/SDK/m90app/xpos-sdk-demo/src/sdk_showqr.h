#pragma once

void showQrTest();