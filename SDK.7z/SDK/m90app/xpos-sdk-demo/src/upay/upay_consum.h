#pragma once

int upay_consum(void);
int tt_upay_consum(void);
void sendAndReceiveDemoRequest(const int iSsl, const int port);
