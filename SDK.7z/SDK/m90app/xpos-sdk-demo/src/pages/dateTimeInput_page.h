#pragma once

int time_set_page();