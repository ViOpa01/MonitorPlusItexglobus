#pragma once

int scan_page_proc(char *title, char *buff, int size,  int timeover);