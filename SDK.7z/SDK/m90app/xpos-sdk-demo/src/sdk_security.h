#pragma once

void PinTest();
void mkskTest();
void dukptTest();
void RsaTest();