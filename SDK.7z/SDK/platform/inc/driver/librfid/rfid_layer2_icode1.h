#ifndef _RFID_L2_ICODE1_H
#define _RFID_L2_ICODE1_H

#ifdef __LIBRFID__

#include <librfid/rfid_layer2.h>
extern const struct rfid_layer2 rfid_layer2_icode1;


#endif /* __LIBRFID__ */
#endif /* _ISO15693_H */
