#ifndef _RFID_READER_SPIDEV_H
#define _RFID_READER_SPIDEV_H

extern struct rfid_reader rfid_reader_spidev;

#endif
