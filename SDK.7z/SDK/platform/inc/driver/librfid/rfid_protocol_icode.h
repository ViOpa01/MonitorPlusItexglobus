#ifndef _RFID_PROTOCOL_TAGIT_H
#define _RFID_PROTOCOL_TAGIT_H

#ifdef __LIBRFID__

extern const struct rfid_protocol rfid_protocol_icode;

#endif /* __LIBRFID__ */

#endif
