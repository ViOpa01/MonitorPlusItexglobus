#ifndef __READER_M90L_H
#define __READER_M90L_H

/* This header file describes the USB protocol of the OpenPCD RFID reader */

//#include <sys/types.h>

extern  struct rfid_reader rfid_reader_m90l;

#endif
