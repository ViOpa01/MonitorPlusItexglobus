#pragma once

void sdk_main_page();
int sdk_power_proc_page(void *pval);