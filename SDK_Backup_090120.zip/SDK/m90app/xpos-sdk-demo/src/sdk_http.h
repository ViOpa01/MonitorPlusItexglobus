#pragma once

void sdk_http_test();
void sdk_https_test();
