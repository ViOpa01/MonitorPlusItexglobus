#pragma once

// Declaring app information
#define APP_NAME "TamsLite"
#define APP_VER "V1.1.2"
#define APP_MODEL "Morefun"