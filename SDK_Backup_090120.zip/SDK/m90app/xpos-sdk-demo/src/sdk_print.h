#pragma once

void sdk_print();
void creat_bmp();
#define TESTIMG "test.bmp"

