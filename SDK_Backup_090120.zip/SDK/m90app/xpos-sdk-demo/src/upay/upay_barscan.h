#pragma once

int upay_barscan(void);
