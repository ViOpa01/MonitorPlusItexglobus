#pragma once

int upay_consum(void);
int tt_upay_consum(void);
